import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addresscard',
  templateUrl: './addresscard.component.html',
  styleUrls: ['./addresscard.component.css']
})
export class AddresscardComponent implements OnInit {

  user: any;
  constructor() {
      this.user ={
        name : 'sakshi raut',
        title : 'software Associate',
        address : 'chennai sipcot,41250',
        phone:[
          '9854225585','9775646655'
        ]
      };
    }
  ngOnInit() {
  }

}
