import { Component, OnInit } from '@angular/core';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(public service:DemoServiceService) { }

  ngOnInit() {
  }
  addNumbers(number1,number2){
    this.service.displayAddition(number1,number2);
  }

  subNumbers(number1, number2){
    this.service.displaySubtraction(number1,number2);
  }

  multNumbers(number1,number2){
    this.service.displayMultiplication(number1,number2);
  }

  divNumbers(number1,number2){
    this.service.displayDivision(number1,number2);
  }


  // add employee
  addEmployee(id,name,salary,department){
    alert(id + " " + name + " " + salary + " " + department);
}
}