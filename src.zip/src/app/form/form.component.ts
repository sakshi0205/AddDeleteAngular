import { Component, OnInit } from '@angular/core';
import { DemoServiceService } from '../demo-service.service';
import employee from '../data/employeedata.json';


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  employees: any;

  constructor(public service: DemoServiceService) {
    this.employees = employee;
  }

  ngOnInit() {


  }

  getData(city) {
    this.service.display(city);
  }

  deletedata(i) {
    this.employees.splice(i, 1)
  }

  addEmployee(form) {
    console.log(form.id, form.name, form.salary);

  }


}
