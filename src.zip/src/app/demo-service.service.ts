import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class DemoServiceService {


display(city)
{
  alert("city is :"+city);
}
displayUserInfo(uname, upass){
  alert(uname+ " "+upass);
}

displayAddition(num1,num2){
  alert(num1 + num2);
}

displaySubtraction(num1,num2){
  alert(num1 - num2);
}

displayMultiplication(num1,num2){
  alert(num1 * num2);
}

displayDivision(num1,num2){
  alert(num1 / num2);

 
  { 
  
  }
  
}
}